async function getCsrf(){const r=await fetch("/api/csrf",{credentials:"same-origin"});return (await r.json()).csrfToken}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function init(){
 const cfg=await fetch("/api/config").then(r=>r.json());
 document.getElementById("discordJoin").href=cfg.discordUrl;
 document.getElementById("discordBottom").href=cfg.discordUrl;
 document.getElementById("youtubeLink").href="https://www.youtube.com/"+cfg.youtubeHandle;
 document.getElementById("serverIp").textContent=cfg.serverIp;
 const ranks=await fetch("/api/ranks").then(r=>r.json());
 if(ranks.length)document.getElementById("rankList").innerHTML=ranks.map(p=>`<div class="rank-card"><b>${esc(p.rank.toUpperCase())}</b><span>${esc(p.playerName)}</span></div>`).join("");
}
document.getElementById("applicationForm").addEventListener("submit",async e=>{
 e.preventDefault();const status=document.getElementById("formStatus");status.textContent="Submitting…";
 try{const token=await getCsrf();const r=await fetch("/api/applications",{method:"POST",headers:{"x-csrf-token":token},body:new FormData(e.currentTarget),credentials:"same-origin"});const d=await r.json();if(!r.ok)throw new Error(d.error||"Could not submit.");status.textContent="Application submitted! Join Discord for updates.";status.className="status success";e.currentTarget.reset();}
 catch(err){status.textContent=err.message;status.className="status error";}
});
init().catch(()=>{});
