let csrfToken="";
async function api(url,options={}){const headers={...(options.headers||{}),"x-csrf-token":csrfToken};if(options.body)headers["content-type"]="application/json";const r=await fetch(url,{...options,headers,credentials:"same-origin"});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||"Request failed");return d}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function boot(){
 csrfToken=(await fetch("/api/csrf").then(r=>r.json())).csrfToken;
 const me=await fetch("/api/me").then(r=>r.json());
 if(!me.isOwner){document.getElementById("ownerGreeting").innerHTML='Access denied. Sign in using the verified Google account <b>yashsharma55213@gmail.com</b>. <a class="text-link" href="/auth/google">Sign in with Google ↗</a>';return;}
 document.getElementById("ownerGreeting").textContent=`Signed in as ${me.email} — verified owner access`;
 document.getElementById("adminContent").hidden=false;await Promise.all([loadApps(),loadRanks()]);
}
async function loadApps(){
 const apps=await api("/api/admin/applications");
 document.getElementById("applications").innerHTML=apps.length?apps.map(a=>`<article class="application-card"><h3>${esc(a.playerName)} <span class="meta">· ${esc(a.status)}</span></h3><div class="meta">Discord: ${esc(a.discordName)} · Age: ${esc(a.age)} · ${esc(a.createdAt)}</div><p>${esc(a.message)}</p>${a.fileKey?`<p><a class="text-link" href="/uploads/download?id=${a.id}">Download attachment: ${esc(a.fileOriginalName||"file")}</a></p>`:""}<div class="application-actions"><select id="status-${a.id}"><option ${a.status==="Pending"?"selected":""}>Pending</option><option ${a.status==="Approved"?"selected":""}>Approved</option><option ${a.status==="Rejected"?"selected":""}>Rejected</option></select><button class="btn gold small" onclick="updateStatus(${a.id})">Update status</button></div></article>`).join(""):'<p class="meta">No applications yet.</p>';
}
async function updateStatus(id){try{await api(`/api/admin/applications/${id}`,{method:"PATCH",body:JSON.stringify({status:document.getElementById(`status-${id}`).value})});await loadApps()}catch(e){alert(e.message)}}
async function loadRanks(){const ranks=await api("/api/admin/ranks");document.getElementById("managedRanks").innerHTML=ranks.map(p=>`<div class="managed-row"><span>${esc(p.playerName)} — <b>${esc(p.rank)}</b></span><button onclick="deleteRank(${p.id})">Remove</button></div>`).join("")||'<p class="meta">No custom player ranks yet.</p>';}
async function deleteRank(id){try{await api(`/api/admin/ranks/${id}`,{method:"DELETE"});await loadRanks()}catch(e){alert(e.message)}}
document.getElementById("rankForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await api("/api/admin/ranks",{method:"POST",body:JSON.stringify({playerName:f.get("playerName"),rank:f.get("rank")})});e.currentTarget.reset();await loadRanks()}catch(err){alert(err.message)}});
document.getElementById("refreshApps").addEventListener("click",()=>loadApps().catch(e=>alert(e.message)));
document.getElementById("logout").addEventListener("click",async()=>{try{await api("/auth/logout",{method:"POST"});location.href="/"}catch(e){alert(e.message)}});
boot().catch(e=>{document.getElementById("ownerGreeting").textContent=e.message});
