const OWNER_DEFAULT = "yashsharma55213@gmail.com";
const RANKS = ["Owner", "Admin", "Moderator", "MVP", "VIP", "Member"];
const MAX_FILE = 5 * 1024 * 1024;

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers }
  });
}
function redirect(url, headers = {}) {
  return new Response(null, { status: 302, headers: { location: url, ...headers } });
}
function cookieMap(request) {
  const out = {};
  for (const part of (request.headers.get("Cookie") || "").split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function setCookie(name, value, maxAge, secure = true, httpOnly = true) {
  return `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=${maxAge}; SameSite=Lax${secure ? "; Secure" : ""}${httpOnly ? "; HttpOnly" : ""}`;
}
function clearCookie(name, secure = true) {
  return `${name}=; Path=/; Max-Age=0; SameSite=Lax${secure ? "; Secure" : ""}; HttpOnly`;
}
function b64url(bytes) {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function unb64url(value) {
  const s = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(s + "=".repeat((4 - s.length % 4) % 4));
  return Uint8Array.from(binary, c => c.charCodeAt(0));
}
async function hmac(secret, value) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value)));
}
async function signObject(obj, secret) {
  const body = b64url(new TextEncoder().encode(JSON.stringify(obj)));
  return `${body}.${b64url(await hmac(secret, body))}`;
}
async function verifyObject(token, secret) {
  if (!token || !token.includes(".")) return null;
  const [body, sig] = token.split(".");
  const expected = b64url(await hmac(secret, body));
  if (sig.length !== expected.length) return null;
  let mismatch = 0;
  for (let i = 0; i < sig.length; i++) mismatch |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  if (mismatch) return null;
  try { return JSON.parse(new TextDecoder().decode(unb64url(body))); } catch { return null; }
}
function secureRequest(request) { return new URL(request.url).protocol === "https:"; }
async function ownerSession(request, env) {
  const token = cookieMap(request).by_session;
  const session = await verifyObject(token, env.SESSION_SECRET);
  if (!session || session.exp < Date.now() || session.email !== (env.OWNER_EMAIL || OWNER_DEFAULT).toLowerCase() || session.verified !== true) return null;
  return session;
}
async function requireCsrf(request, env) {
  const cookies = cookieMap(request);
  const header = request.headers.get("x-csrf-token");
  const token = cookies.by_csrf;
  if (!token || !header || token !== header || token.length < 32) return false;
  return true;
}
function clean(value, max) { return String(value || "").trim().replace(/\s+/g, " ").slice(0, max); }
function safeName(value) { return String(value || "attachment").replace(/[^\w.\- ()]/g, "_").slice(0, 100); }
function mimeAllowed(file) {
  const ext = file.name.toLowerCase().split(".").pop();
  const allowed = {
    pdf: ["application/pdf"], png: ["image/png"], jpg: ["image/jpeg"],
    jpeg: ["image/jpeg"], txt: ["text/plain"]
  };
  return allowed[ext]?.includes(file.type) ? ext : null;
}
async function ownerOnly(request, env) {
  const session = await ownerSession(request, env);
  return session;
}
async function exchangeGoogleCode(code, env, redirectUri) {
  const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: env.GOOGLE_CLIENT_ID,
      client_secret: env.GOOGLE_CLIENT_SECRET,
      redirect_uri: redirectUri,
      grant_type: "authorization_code"
    })
  });
  if (!tokenResponse.ok) throw new Error("Google token exchange failed");
  const tokenData = await tokenResponse.json();
  const profileResponse = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
    headers: { authorization: `Bearer ${tokenData.access_token}` }
  });
  if (!profileResponse.ok) throw new Error("Google profile lookup failed");
  const profile = await profileResponse.json();
  return {
    email: String(profile.email || "").toLowerCase(),
    emailVerified: profile.verified_email === true,
    name: String(profile.name || profile.email || "Owner").slice(0, 100),
    googleId: String(profile.id || "")
  };
}
async function api(request, env) {
  const url = new URL(request.url);
  const method = request.method;
  const secure = secureRequest(request);
  const owner = await ownerOnly(request, env);

  if (method === "GET" && url.pathname === "/api/config") {
    return json({
      discordUrl: env.DISCORD_URL || "https://discord.gg/3nsZwChveQ",
      youtubeHandle: env.YOUTUBE_HANDLE || "@BETTERYASH",
      serverIp: env.SERVER_IP || "Check the Discord server for the SMP IP",
      serverVersion: env.SERVER_VERSION || "Add your Minecraft version"
    });
  }
  if (method === "GET" && url.pathname === "/api/csrf") {
    const cookies = cookieMap(request);
    const token = cookies.by_csrf || b64url(crypto.getRandomValues(new Uint8Array(32)));
    return json({ csrfToken: token }, 200, { "set-cookie": setCookie("by_csrf", token, 60 * 60 * 3, secure, false) });
  }
  if (method === "GET" && url.pathname === "/api/me") {
    return json({ isOwner: !!owner, email: owner?.email || null, displayName: owner?.name || null });
  }
  if (method === "GET" && url.pathname === "/api/ranks") {
    const { results } = await env.DB.prepare(
      "SELECT player_name AS playerName, rank FROM players ORDER BY CASE rank WHEN 'Owner' THEN 1 WHEN 'Admin' THEN 2 WHEN 'Moderator' THEN 3 WHEN 'MVP' THEN 4 WHEN 'VIP' THEN 5 ELSE 6 END, player_name"
    ).all();
    return json(results || []);
  }

  if (["POST", "PATCH", "DELETE"].includes(method) && !(await requireCsrf(request, env))) {
    return json({ error: "Security token missing or expired. Refresh the page and try again." }, 403);
  }

  if (method === "POST" && url.pathname === "/api/applications") {
    const form = await request.formData();
    const playerName = clean(form.get("playerName"), 24);
    const discordName = clean(form.get("discordName"), 50);
    const age = clean(form.get("age"), 2);
    const message = String(form.get("message") || "").trim().slice(0, 1500);
    if (playerName.length < 3 || discordName.length < 2 || !/^\d{1,2}$/.test(age) || message.length < 20) {
      return json({ error: "Please complete every field. Message must be at least 20 characters." }, 400);
    }
    let fileKey = null, originalName = null;
    const file = form.get("attachment");
    if (file && typeof file === "object" && file.size > 0) {
      if (file.size > MAX_FILE) return json({ error: "File size must be 5 MB or less." }, 400);
      const ext = mimeAllowed(file);
      if (!ext) return json({ error: "Only PDF, PNG, JPG, JPEG or TXT files are allowed." }, 400);
      fileKey = `application-files/${crypto.randomUUID()}.${ext}`;
      originalName = safeName(file.name);
      await env.UPLOADS.put(fileKey, await file.arrayBuffer(), {
        httpMetadata: { contentType: file.type },
        customMetadata: { originalName }
      });
    }
    await env.DB.prepare(
      "INSERT INTO applications (player_name, discord_name, age, message, file_key, file_original_name) VALUES (?, ?, ?, ?, ?, ?)"
    ).bind(playerName, discordName, age, message, fileKey, originalName).run();
    return json({ ok: true, message: "Application submitted." }, 201);
  }

  if (url.pathname.startsWith("/api/admin/") && !owner) return json({ error: "Verified owner access only." }, 403);

  if (method === "GET" && url.pathname === "/api/admin/applications") {
    const { results } = await env.DB.prepare(
      "SELECT id, player_name AS playerName, discord_name AS discordName, age, message, file_key AS fileKey, file_original_name AS fileOriginalName, status, created_at AS createdAt FROM applications ORDER BY id DESC LIMIT 200"
    ).all();
    return json(results || []);
  }
  const appStatusMatch = url.pathname.match(/^\/api\/admin\/applications\/(\d+)$/);
  if (method === "PATCH" && appStatusMatch) {
    const body = await request.json();
    const status = clean(body.status, 20);
    if (!["Pending", "Approved", "Rejected"].includes(status)) return json({ error: "Invalid status." }, 400);
    const result = await env.DB.prepare("UPDATE applications SET status = ? WHERE id = ?").bind(status, Number(appStatusMatch[1])).run();
    if (!result.meta.changes) return json({ error: "Application not found." }, 404);
    return json({ ok: true });
  }
  if (method === "GET" && url.pathname === "/api/admin/ranks") {
    const { results } = await env.DB.prepare("SELECT id, player_name AS playerName, rank FROM players ORDER BY player_name").all();
    return json(results || []);
  }
  if (method === "POST" && url.pathname === "/api/admin/ranks") {
    const body = await request.json();
    const playerName = clean(body.playerName, 24), rank = clean(body.rank, 20);
    if (playerName.length < 3 || !RANKS.includes(rank)) return json({ error: "Enter a valid player name and rank." }, 400);
    await env.DB.prepare(
      "INSERT INTO players (player_name, rank) VALUES (?, ?) ON CONFLICT(player_name) DO UPDATE SET rank = excluded.rank, updated_at = datetime('now')"
    ).bind(playerName, rank).run();
    return json({ ok: true });
  }
  const rankMatch = url.pathname.match(/^\/api\/admin\/ranks\/(\d+)$/);
  if (method === "DELETE" && rankMatch) {
    await env.DB.prepare("DELETE FROM players WHERE id = ?").bind(Number(rankMatch[1])).run();
    return json({ ok: true });
  }
  if (method === "GET" && url.pathname.startsWith("/uploads/")) {
    const id = Number(url.searchParams.get("id"));
    if (!Number.isInteger(id) || id < 1) return json({ error: "Invalid attachment." }, 400);
    const row = await env.DB.prepare("SELECT file_key, file_original_name FROM applications WHERE id = ?").bind(id).first();
    if (!row?.file_key) return json({ error: "Attachment not found." }, 404);
    const object = await env.UPLOADS.get(row.file_key);
    if (!object) return json({ error: "File not found." }, 404);
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set("content-disposition", `attachment; filename="${safeName(row.file_original_name)}"`);
    headers.set("cache-control", "private, no-store");
    return new Response(object.body, { headers });
  }
  if (method === "POST" && url.pathname === "/auth/logout") {
    return json({ ok: true }, 200, { "set-cookie": clearCookie("by_session", secure) });
  }
  return null;
}

async function auth(request, env) {
  const url = new URL(request.url);
  const secure = secureRequest(request);
  if (url.pathname === "/auth/google") {
    if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET || !env.SESSION_SECRET) {
      return new Response("Owner login is not configured. Add Google OAuth credentials and SESSION_SECRET in Worker settings.", { status: 503 });
    }
    const state = b64url(crypto.getRandomValues(new Uint8Array(24)));
    const signedState = await signObject({ state, exp: Date.now() + 10 * 60 * 1000 }, env.SESSION_SECRET);
    const redirectUri = env.GOOGLE_REDIRECT_URI || `${url.origin}/auth/google/callback`;
    const google = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    google.search = new URLSearchParams({
      client_id: env.GOOGLE_CLIENT_ID,
      redirect_uri: redirectUri,
      response_type: "code",
      scope: "openid email profile",
      state,
      prompt: "select_account"
    });
    return redirect(google.toString(), { "set-cookie": setCookie("by_oauth_state", signedState, 600, secure, true) });
  }
  if (url.pathname === "/auth/google/callback") {
    const stateCookie = cookieMap(request).by_oauth_state;
    const saved = await verifyObject(stateCookie, env.SESSION_SECRET || "");
    const state = url.searchParams.get("state");
    const code = url.searchParams.get("code");
    if (!saved || saved.exp < Date.now() || saved.state !== state || !code) return redirect("/?login=failed", { "set-cookie": clearCookie("by_oauth_state", secure) });
    try {
      const redirectUri = env.GOOGLE_REDIRECT_URI || `${url.origin}/auth/google/callback`;
      const profile = await exchangeGoogleCode(code, env, redirectUri);
      const ownerEmail = (env.OWNER_EMAIL || OWNER_DEFAULT).toLowerCase();
      if (!profile.emailVerified || profile.email !== ownerEmail) {
        return redirect("/?login=not-owner", { "set-cookie": [clearCookie("by_oauth_state", secure), clearCookie("by_session", secure)] });
      }
      const session = await signObject({
        email: profile.email, name: profile.name, verified: true,
        exp: Date.now() + 8 * 60 * 60 * 1000
      }, env.SESSION_SECRET);
      return redirect("/admin.html", {
        "set-cookie": [
          setCookie("by_session", session, 8 * 60 * 60, secure, true),
          clearCookie("by_oauth_state", secure)
        ]
      });
    } catch (e) {
      return redirect("/?login=failed", { "set-cookie": clearCookie("by_oauth_state", secure) });
    }
  }
  return null;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    try {
      let response = null;
      if (url.pathname.startsWith("/auth/")) response = await auth(request, env);
      if (!response && (url.pathname.startsWith("/api/") || url.pathname.startsWith("/uploads/"))) {
        response = await api(request, env);
      }
      if (response) {
        const headers = new Headers(response.headers);
        headers.set("x-content-type-options", "nosniff");
        headers.set("referrer-policy", "strict-origin-when-cross-origin");
        headers.set("x-frame-options", "DENY");
        headers.set("content-security-policy", "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");
        return new Response(response.body, { status: response.status, headers });
      }
      return env.ASSETS.fetch(request);
    } catch (error) {
      console.error("Worker request failed:", error);
      return json({ error: "Server error. Please try again." }, 500);
    }
  }
};
