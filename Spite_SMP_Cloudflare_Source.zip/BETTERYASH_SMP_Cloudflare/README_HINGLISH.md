# Spite SMP — Cloudflare Version 2

Ye version Cloudflare Workers + D1 + R2 par chalta hai. Ismein Express, SQLite, Node server ya separate backend host ki zaroorat nahi hai.

## Is project mein kya hai?
- Black + Royal Gold website design
- Discord invite: https://discord.gg/3nsZwChveQ
- YouTube: @BETTERYASH
- Server IP message: "Check the Discord server for the SMP IP"
- Forum application form
- PDF / PNG / JPG / TXT attachment upload (maximum 5 MB)
- D1 mein applications aur ranks save
- R2 mein private file storage
- Google verified owner login: yashsharma55213@gmail.com
- Owner dashboard: application approve/reject, player ranks manage, private attachments download

## Zaroori baat
Aapko Cloudflare account mein D1 database aur R2 bucket create karna hoga. Google OAuth credentials bhi configure karne honge. ZIP ready source code hai; ye apne aap deploy nahi hua.

## Step 1 — ZIP extract karo
ZIP ko PC/laptop par extract karo. Project folder `SPITE_SMP_Cloudflare` open karo.

## Step 2 — Node.js aur Wrangler
PC par Node.js 20+ install hona chahiye. Terminal/Command Prompt mein project folder open karke:
```bash
npm install
```

## Step 3 — Cloudflare D1 database banao
```bash
npx wrangler d1 create betteryash-db
```
Command output mein jo `database_id` mile, use `wrangler.jsonc` ke `REPLACE_WITH_D1_DATABASE_ID` ki jagah paste karo.

Schema apply karo:
```bash
npx wrangler d1 migrations apply betteryash-db --remote
```

## Step 4 — Cloudflare R2 bucket banao
```bash
npx wrangler r2 bucket create betteryash-uploads
```
Bucket name `betteryash-uploads` hi rehna chahiye, ya `wrangler.jsonc` mein same name update karo.

## Step 5 — Google verified owner login
Google Cloud Console mein OAuth Client ID (Web application) banao.
Authorized redirect URI:
`https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev/auth/google/callback`

Agar custom domain use karoge, redirect URI:
`https://YOUR-DOMAIN/auth/google/callback`

Cloudflare Worker ke secrets set karo:
```bash
npx wrangler secret put SESSION_SECRET
npx wrangler secret put GOOGLE_CLIENT_ID
npx wrangler secret put GOOGLE_CLIENT_SECRET
```
SESSION_SECRET ke liye random, lamba secret use karo. Client ID aur secret ko public chat ya source file mein mat daalna.

Google OAuth redirect URI ko `wrangler.jsonc` ke `GOOGLE_REDIRECT_URI` variable mein set karna ho to `[vars]` section add karo, ya default use karo: current website origin + `/auth/google/callback`.

Owner email fixed default `yashsharma55213@gmail.com` hai. Worker Google profile se verified email check karta hai; sirf email type karne se owner access nahi milta.

## Step 6 — Local preview
Local testing ke liye `.dev.vars.example` ko `.dev.vars` naam se copy karo aur values bharo. Google OAuth ke liye local redirect URI:
`http://localhost:8787/auth/google/callback`

D1 local schema:
```bash
npx wrangler d1 migrations apply betteryash-db --local
```
Run:
```bash
npm run dev
```

## Step 7 — Deploy
```bash
npm run deploy
```
Deploy ke baad `https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev` open karo.

## Step 8 — Server IP
Server IP abhi Discord instruction par set hai. Agar aapko website par actual IP show karna hai, `wrangler.jsonc` ke `SERVER_IP` value ko update karke redeploy karo. Version bhi `SERVER_VERSION` mein update kar sakte ho.

## Dashboard
Public website: Worker URL  
Owner login: Worker URL + `/auth/google`  
Admin dashboard: Worker URL + `/admin.html`

## Security notes
- Owner login Google verified email ke saath exact email match karta hai.
- Session cookie signed, HTTP-only aur 8 ghante mein expire hoti hai.
- Mutating API requests CSRF token check karti hain.
- File upload type allowlist aur 5 MB size limit use karta hai.
- Attachments R2 mein private rehte hain; download route owner login require karta hai.
- Secrets ko `wrangler secret put` se set karo; source files mein secret mat likho.
- Public site par real player personal information mat dikhana. Applications owner dashboard ke andar hi rehti hain.

## Common issue
**D1 error:** Check database ID and run remote migration.
**R2 error:** Bucket name `betteryash-uploads` exact hona chahiye.
**Google redirect_uri_mismatch:** Google Cloud Console mein callback URL exact same add karo.
**Owner access denied:** Browser mein wahi Google account sign in karo jiska verified email `yashsharma55213@gmail.com` hai.
